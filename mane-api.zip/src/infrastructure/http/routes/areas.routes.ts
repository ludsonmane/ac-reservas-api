// api/src/infrastructure/http/routes/areas.routes.ts
import { Router } from 'express';
import { prisma } from '../../db/prisma';
import { requireAuth, requireRole } from '../middlewares/requireAuth';

export const areasRouter = Router();

/**
 * GET /v1/areas
 * Filtros: page, pageSize, unitId, search, active
 * Auth: STAFF/ADMIN
 */
areasRouter.get('/', requireAuth, requireRole(['STAFF', 'ADMIN']), async (req, res) => {
  const { page = '1', pageSize = '20', unitId, search, active } = req.query as Record<string, string>;
  const take = Math.max(1, Math.min(200, Number(pageSize)));
  const skip = (Math.max(1, Number(page)) - 1) * take;

  const where: any = {};
  if (unitId) where.unitId = unitId;
  if (typeof active !== 'undefined') where.isActive = String(active) === 'true';
  if (search?.trim()) {
    where.OR = [
      { name: { contains: search.trim(), mode: 'insensitive' } },
      { unit: { name: { contains: search.trim(), mode: 'insensitive' } } },
    ];
  }

  const [items, total] = await Promise.all([
    prisma.area.findMany({
      where,
      skip,
      take,
      orderBy: [{ unit: { name: 'asc' } }, { name: 'asc' }],
      include: { unit: { select: { id: true, name: true, slug: true } } },
    }),
    prisma.area.count({ where }),
  ]);

  res.json({
    items,
    total,
    page: Math.max(1, Number(page)),
    pageSize: take,
    totalPages: Math.ceil(total / take),
  });
});

/**
 * POST /v1/areas
 * body: { unitId: string, name: string, capacity: number, isActive?: boolean }
 * Auth: STAFF/ADMIN
 */
areasRouter.post('/', requireAuth, requireRole(['STAFF', 'ADMIN']), async (req, res) => {
  const { unitId, name, capacity = 0, isActive = true } = req.body || {};
  if (!unitId) return res.status(400).json({ error: 'unitId é obrigatório' });
  if (!name?.trim()) return res.status(400).json({ error: 'name é obrigatório' });
  if (Number(capacity) < 0) return res.status(400).json({ error: 'capacity deve ser >= 0' });

  const unit = await prisma.unit.findUnique({ where: { id: unitId } });
  if (!unit) return res.status(400).json({ error: 'Unidade inexistente' });

  try {
    const created = await prisma.area.create({
      data: {
        unitId,
        name: name.trim(),
        capacity: Number(capacity),
        isActive: Boolean(isActive),
      },
    });
    res.status(201).json(created);
  } catch (e: any) {
    if (String(e?.code) === 'P2002') {
      return res.status(409).json({ error: 'Já existe uma área com esse nome nesta unidade' });
    }
    res.status(400).json({ error: 'Erro ao criar área', details: e?.message });
  }
});

/**
 * GET /v1/areas/:id
 * Auth: STAFF/ADMIN
 */
areasRouter.get('/:id', requireAuth, requireRole(['STAFF', 'ADMIN']), async (req, res) => {
  const a = await prisma.area.findUnique({
    where: { id: req.params.id },
    include: { unit: { select: { id: true, name: true, slug: true } } },
  });
  if (!a) return res.status(404).json({ error: 'Área não encontrada' });
  res.json(a);
});

/**
 * PUT /v1/areas/:id
 * body: { unitId?, name?, capacity?, isActive? }
 * Auth: STAFF/ADMIN
 */
areasRouter.put('/:id', requireAuth, requireRole(['STAFF', 'ADMIN']), async (req, res) => {
  const { unitId, name, capacity, isActive } = req.body || {};
  const data: any = {};

  if (typeof unitId !== 'undefined') {
    const unit = await prisma.unit.findUnique({ where: { id: String(unitId) } });
    if (!unit) return res.status(400).json({ error: 'Unidade inexistente' });
    data.unitId = String(unitId);
  }
  if (typeof name !== 'undefined') {
    if (!String(name).trim()) return res.status(400).json({ error: 'name é obrigatório' });
    data.name = String(name).trim();
  }
  if (typeof capacity !== 'undefined') {
    if (Number(capacity) < 0) return res.status(400).json({ error: 'capacity deve ser >= 0' });
    data.capacity = Number(capacity);
  }
  if (typeof isActive !== 'undefined') {
    data.isActive = Boolean(isActive);
  }

  try {
    const updated = await prisma.area.update({ where: { id: req.params.id }, data });
    res.json(updated);
  } catch (e: any) {
    if (String(e?.code) === 'P2025') return res.status(404).json({ error: 'Área não encontrada' });
    if (String(e?.code) === 'P2002') return res.status(409).json({ error: 'Já existe uma área com esse nome nesta unidade' });
    res.status(400).json({ error: 'Erro ao atualizar área', details: e?.message });
  }
});

/**
 * DELETE /v1/areas/:id
 * Regra: 409 se existir reserva vinculada
 * Auth: ADMIN
 */
areasRouter.delete('/:id', requireAuth, requireRole(['ADMIN']), async (req, res) => {
  const id = req.params.id;

  const rCount = await prisma.reservation.count({ where: { areaId: id } });
  if (rCount > 0) {
    return res.status(409).json({ error: 'Não é possível excluir: existem reservas nesta área' });
  }

  try {
    await prisma.area.delete({ where: { id } });
    res.sendStatus(204);
  } catch (e: any) {
    if (String(e?.code) === 'P2025') return res.status(404).json({ error: 'Área não encontrada' });
    res.status(400).json({ error: 'Erro ao excluir área', details: e?.message });
  }
});

/**
 * Público — áreas ativas por unidade (para selects do front)
 * GET /v1/areas/public/by-unit/:unitId
 */
areasRouter.get('/public/by-unit/:unitId', async (req, res) => {
  const items = await prisma.area.findMany({
    where: { unitId: req.params.unitId, isActive: true },
    select: { id: true, name: true, capacity: true },
    orderBy: { name: 'asc' },
  });
  res.json(items);
});
