// api/src/infrastructure/http/routes/reservations.routes.ts
import { Router } from 'express';
import crypto from 'crypto';
import QRCode from 'qrcode';
import dayjs from 'dayjs';

import { PrismaReservationRepository } from '../../db/PrismaReservationRepository';
import { CreateReservation } from '../../../application/use-cases/CreateReservation';
import { ListReservations } from '../../../application/use-cases/ListReservations';
import { GetReservationById } from '../../../application/use-cases/GetReservationById';
import { UpdateReservation } from '../../../application/use-cases/UpdateReservation';
import { DeleteReservation } from '../../../application/use-cases/DeleteReservation';
import { ReservationController } from '../../../interfaces/http/controllers/ReservationController';
import { prisma } from '../../db/prisma';

// ⬇️ auth/role guards
import { requireAuth, requireRole } from '../middlewares/requireAuth';

// ⬇️ disponibilidade de áreas
import { areasService } from '../../../modules/areas/areas.service';

const repo = new PrismaReservationRepository();
const controller = new ReservationController(
  new CreateReservation(repo),
  new ListReservations(repo),
  new GetReservationById(repo),
  new UpdateReservation(repo),
  new DeleteReservation(repo)
);

export const reservationsRouter = Router();

/* =========================================================================
   Helpers
   ========================================================================= */

function toYMD(dateISO: string | Date): string {
  const d = typeof dateISO === 'string' ? new Date(dateISO) : dateISO;
  return dayjs(d).format('YYYY-MM-DD');
}

async function resolveUnit(input: { unitId?: string | null; unit?: string | null }) {
  // Preferir unitId se vier:
  if (input.unitId) {
    const u = await prisma.unit.findUnique({ where: { id: String(input.unitId) } });
    if (u) return { unitId: u.id, unitName: u.name };
  }
  // Tentar pelo nome/slug legado se vier "unit"
  const raw = (input.unit || '').trim();
  if (raw) {
    // busca por slug exato ou nome case-insensitive
    const u = await prisma.unit.findFirst({
      where: {
        OR: [
          { slug: raw },
          { name: { equals: raw, mode: 'insensitive' } },
        ],
      },
    });
    if (u) return { unitId: u.id, unitName: u.name };
  }
  return { unitId: null as string | null, unitName: null as string | null };
}

async function resolveArea(input: { areaId?: string | null; area?: string | null; unitId?: string | null }) {
  if (input.areaId) {
    const a = await prisma.area.findUnique({ where: { id: String(input.areaId) } });
    if (a) return { areaId: a.id, areaName: a.name };
  }
  const raw = (input.area || '').trim();
  if (raw && input.unitId) {
    const a = await prisma.area.findFirst({
      where: {
        unitId: String(input.unitId),
        name: { equals: raw, mode: 'insensitive' },
      },
    });
    if (a) return { areaId: a.id, areaName: a.name };
  }
  return { areaId: null as string | null, areaName: null as string | null };
}

/**
 * Middleware que:
 * - Resolve unitId/areaId (e unit/areaName legados)
 * - Valida capacidade diária (people + kids) da área escolhida
 * - Normaliza tipos numéricos
 */
async function enrichAndValidate(req: any, res: any, next: any) {
  try {
    const body = req.body || {};

    // normaliza números
    const people = Number(body.people ?? 0);
    const kids = Number(body.kids ?? 0);
    body.people = Number.isFinite(people) ? people : 0;
    body.kids = Number.isFinite(kids) ? kids : 0;

    // data obrigatória para validação de capacidade quando houver área
    const reservationDate = body.reservationDate ? new Date(body.reservationDate) : null;

    // resolve unidade
    const { unitId, unitName } = await resolveUnit({ unitId: body.unitId, unit: body.unit });
    body.unitId = unitId;
    // legado:
    if (!body.unit && unitName) body.unit = unitName;

    // resolve área (depende de unitId)
    const { areaId, areaName } = await resolveArea({ areaId: body.areaId, area: body.area, unitId });
    body.areaId = areaId;
    // legado:
    if (!body.areaName && areaName) body.areaName = areaName;
    if (!body.area && areaName) body.area = areaName;

    // valida capacidade se tivermos área + data
    if (areaId && reservationDate) {
      const ymd = toYMD(reservationDate);
      const list = await areasService.listByUnitPublic(String(unitId), ymd);
      const found = list.find(a => a.id === areaId);
      if (!found) {
        return res.status(400).json({ error: { code: 'AREA_NOT_FOUND', message: 'Área não encontrada/ativa para a unidade selecionada.' } });
      }
      const total = body.people + body.kids;
      const available = (found.available ?? found.remaining ?? 0);
      if (total > available) {
        return res.status(409).json({
          error: {
            code: 'AREA_NO_CAPACITY',
            message: `Esta área não possui vagas suficientes para ${total} pessoa(s) nesta data.`,
            available,
          },
        });
      }
    }

    req.body = body;
    next();
  } catch (e: any) {
    next(e);
  }
}

/* =========================================================================
   Rotas estáticas / específicas (ANTES das paramétricas)
   ========================================================================= */

/**
 * Buscar por código curto via query string
 * GET /v1/reservations/lookup?code=JT5WK6
 */
reservationsRouter.get('/lookup', async (req, res) => {
  const raw = String(req.query.code || '').trim().toUpperCase();
  if (!raw) {
    return res.status(400).json({ error: { message: 'Parâmetro "code" é obrigatório.' } });
  }
  if (!/^[A-Z0-9]{6}$/.test(raw)) {
    return res.status(400).json({ error: { message: 'Código inválido (use 6 caracteres A-Z/0-9).' } });
  }

  const r = await prisma.reservation.findUnique({ where: { reservationCode: raw } });
  if (!r) return res.sendStatus(404);
  res.json(r);
});

/**
 * Buscar por código curto via path
 * GET /v1/reservations/code/:code
 */
reservationsRouter.get('/code/:code', async (req, res) => {
  const code = (req.params.code || '').trim().toUpperCase();
  if (!/^[A-Z0-9]{6}$/.test(code)) {
    return res.status(400).json({ error: { message: 'Código inválido (use 6 caracteres A-Z/0-9).' } });
  }
  const r = await prisma.reservation.findUnique({ where: { reservationCode: code } });
  if (!r) return res.sendStatus(404);
  res.json(r);
});

/**
 * Disponibilidade pública por unidade e data
 * GET /v1/reservations/availability?unitId=...&date=YYYY-MM-DD
 */
reservationsRouter.get('/availability', async (req, res) => {
  const unitId = String(req.query.unitId || '');
  const date = String(req.query.date || '');
  if (!unitId) return res.status(400).json({ error: { message: 'unitId é obrigatório' } });

  const list = await areasService.listByUnitPublic(unitId, date || undefined);
  res.json(list);
});

/**
 * Listar UNIDADES para a UI (compat: apenas nomes)
 * GET /v1/reservations/units
 */
reservationsRouter.get('/units', async (_req, res) => {
  const units = await prisma.unit.findMany({
    where: { isActive: true },
    orderBy: { name: 'asc' },
    select: { name: true },
  });
  res.json(units.map(u => u.name));
});

/**
 * Listar ÁREAS (legado, derivadas das reservas existentes)
 * GET /v1/reservations/areas
 */
reservationsRouter.get('/areas', async (_req, res) => {
  const groups = await prisma.reservation.groupBy({
    by: ['area'],
    where: { area: { not: null } },
  });
  const list = groups
    .map(g => g.area!)
    .filter(Boolean)
    .sort((a, b) => a.localeCompare(b, 'pt-BR'));
  res.json(list);
});

/**
 * Check-in por token (idempotente)
 * GET /v1/reservations/checkin/:token
 * (pública)
 */
reservationsRouter.get('/checkin/:token', async (req, res) => {
  const token = req.params.token;
  const now = new Date();

  const r = await prisma.reservation.findFirst({ where: { qrToken: token } });
  if (!r) return res.status(404).send('<h2>QR inválido</h2>');
  if (r.qrExpiresAt && r.qrExpiresAt < now) return res.status(410).send('<h2>QR expirado</h2>');
  if (r.checkedInAt) return res.status(200).send('<h2>Reserva já validada ✔️</h2>');

  await prisma.reservation.update({
    where: { id: r.id },
    data: { status: 'CHECKED_IN', checkedInAt: now },
  });

  res.status(200).send('<h2>Check-in confirmado! ✔️</h2>');
});

/**
 * Status da reserva (para polling do front)
 * GET /v1/reservations/:id/status
 */
reservationsRouter.get('/:id/status', async (req, res) => {
  const id = req.params.id;
  const r = await prisma.reservation.findUnique({
    where: { id },
    select: { status: true, checkedInAt: true, reservationCode: true },
  });
  if (!r) return res.sendStatus(404);
  res.json(r);
});

/**
 * QR code PNG do check-in (imagem)
 * GET /v1/reservations/:id/qrcode
 */
reservationsRouter.get('/:id/qrcode', async (req, res) => {
  const id = req.params.id;
  const r = await prisma.reservation.findUnique({ where: { id } });
  if (!r) return res.sendStatus(404);

  const base = `${req.protocol}://${req.get('host')}`;
  const checkinUrl = `${base}/v1/reservations/checkin/${encodeURIComponent(r.qrToken)}`;

  try {
    const png = await QRCode.toBuffer(checkinUrl, { width: 384, margin: 2 });

    // Permitir embed cross-origin
    res.setHeader('Content-Type', 'image/png');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');

    res.send(png);
  } catch {
    res.status(500).json({ error: { code: 'QR_ERROR', message: 'Failed to generate QR' } });
  }
});

/* =========================================================================
   CRUD (Controller) — com enrich/validate no CREATE/UPDATE
   ========================================================================= */

reservationsRouter.post(
  '/',
  requireAuth,
  requireRole(['STAFF', 'ADMIN']),
  enrichAndValidate,
  controller.create
);

reservationsRouter.get('/', controller.list);
reservationsRouter.get('/:id', controller.getById);

reservationsRouter.put(
  '/:id',
  requireAuth,
  requireRole(['STAFF', 'ADMIN']),
  enrichAndValidate,
  controller.update
);

reservationsRouter.delete(
  '/:id',
  requireAuth,
  requireRole(['ADMIN']),
  controller.delete
);
