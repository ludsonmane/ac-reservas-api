// src/modules/areas/areas.controller.ts
import type { Request, Response } from 'express';
import { areasService } from './areas.service';

export async function getAreasByUnitPublic(req: Request, res: Response) {
  try {
    const { unitId } = req.params;

    if (!unitId) {
      return res.status(400).json({ message: 'unitId é obrigatório' });
    }

    // lista estática (sem date/time) — já retorna: id, name, photoUrl, capacity, capacityAfternoon, capacityNight, isActive
    const data = await areasService.listByUnitPublic(unitId);

    return res.json(data);
  } catch (err: any) {
    // log com pino, se disponível
    // @ts-ignore
    req.log?.error({ err }, 'Erro em getAreasByUnitPublic');
    return res.status(500).json({ message: 'Erro ao buscar áreas' });
  }
}
